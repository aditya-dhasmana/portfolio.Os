import { create } from "zustand";

const useFinderStore = create((set) => ({
  openFolders: {},
  activeRepoId: null,
  activeFile: null,

  toggleFolder: (id) =>
    set((state) => ({
      openFolders: {
        ...state.openFolders,
        [id]: !state.openFolders[id],
      },
    })),

  setActiveRepo: (id) => set({ activeRepoId: id }),
  setActiveFile: (file) => set({ activeFile: file }),
}));