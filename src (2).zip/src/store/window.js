// src/store/window.js
// Complete replacement file.
// Your current store is too minimal and is missing:
// - focusWindow
// - restoreWindow
// - setWindowPosition
// - setWindowSize
// - setSizeMode
// - initial window configuration
//
// This version works with your Dock, Finder, and windowWrapper.

import { create } from "zustand";
import {
  WINDOW_CONFIG,
  INITIAL_Z_INDEX,
} from "#constants";

let currentZIndex = INITIAL_Z_INDEX;

const useWindowStore = create((set, get) => ({
  // Start with full window config instead of {}
  windows: WINDOW_CONFIG,

  // Open a window
  openWindow: (name, data = null) => {
    currentZIndex += 1;

    set((state) => ({
      windows: {
        ...state.windows,
        [name]: {
          ...state.windows[name],
          isOpen: true,
          isMinimized: false,
          data,
          zIndex: currentZIndex,
        },
      },
    }));
  },

  // Close a window
  closeWindow: (name) => {
    set((state) => ({
      windows: {
        ...state.windows,
        [name]: {
          ...state.windows[name],
          isOpen: false,
          isMinimized: false,
        },
      },
    }));
  },

  // Focus a window (bring to front)
  focusWindow: (name) => {
    currentZIndex += 1;

    set((state) => ({
      windows: {
        ...state.windows,
        [name]: {
          ...state.windows[name],
          zIndex: currentZIndex,
        },
      },
    }));
  },

  // Minimize window
  minimizeWindow: (name) => {
    set((state) => ({
      windows: {
        ...state.windows,
        [name]: {
          ...state.windows[name],
          isMinimized: true,
        },
      },
    }));
  },

  // Restore minimized window
  restoreWindow: (name) => {
    currentZIndex += 1;

    set((state) => ({
      windows: {
        ...state.windows,
        [name]: {
          ...state.windows[name],
          isOpen: true,
          isMinimized: false,
          zIndex: currentZIndex,
        },
      },
    }));
  },

  // Update position
  setWindowPosition: (name, position) => {
    set((state) => ({
      windows: {
        ...state.windows,
        [name]: {
          ...state.windows[name],
          position,
        },
      },
    }));
  },

  // Update size
  setWindowSize: (name, size) => {
    set((state) => ({
      windows: {
        ...state.windows,
        [name]: {
          ...state.windows[name],
          size,
        },
      },
    }));
  },

  // Update size mode
  setSizeMode: (name, sizeMode) => {
    set((state) => ({
      windows: {
        ...state.windows,
        [name]: {
          ...state.windows[name],
          sizeMode,
        },
      },
    }));
  },
}));

export default useWindowStore;