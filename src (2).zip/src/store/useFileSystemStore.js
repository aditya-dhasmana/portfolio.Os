import { create } from "zustand";

const useFileSystemStore = create((set) => ({
  repos: [],
  repoTrees: {},

  setRepos: (repos) => set({ repos }),
  setRepoTree: (id, tree) =>
    set((state) => ({
      repoTrees: {
        ...state.repoTrees,
        [id]: tree,
      },
    })),
}));