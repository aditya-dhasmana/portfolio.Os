import { fetchRepos, fetchRepoTree } from "./github"; // your existing file

export const buildWorkLocation = async () => {
  const repos = await fetchRepos();

  const repoFolders = await Promise.all(
    repos.map(async (repo) => {
      // ⚠️ avoid empty or forked repos (optional filter)
      if (!repo.name) return null;

      let tree = [];

      try {
        tree = await fetchRepoTree(repo.owner.login, repo.name);
      } catch {
        tree = [];
      }

      return {
        id: repo.id,
        name: repo.name,
        icon: "/images/folder.png",
        kind: "folder",

        children: [
          // 📁 SOURCE CODE (real GitHub)
          {
            id: `${repo.id}-source`,
            name: "Source Code",
            icon: "/images/folder.png",
            kind: "folder",
            children: tree,
          },

          // 🌐 LIVE SITE
          {
            id: `${repo.id}-live`,
            name: "Live Site",
            icon: "/images/safari.png",
            kind: "file",
            fileType: "url",
            href: repo.homepage || repo.html_url,
          },

          // 📄 DESCRIPTION
          {
            id: `${repo.id}-txt`,
            name: "Project.txt",
            icon: "/images/txt.png",
            kind: "file",
            fileType: "txt",
            description: [
              repo.description || "No description available.",
              `⭐ Stars: ${repo.stargazers_count}`,
              `🍴 Forks: ${repo.forks_count}`,
            ],
          },

          // 🖼 PREVIEW (fallback)
          {
            id: `${repo.id}-img`,
            name: "Preview.png",
            icon: "/images/image.png",
            kind: "file",
            fileType: "img",
            imageUrl: "/images/project-1.png", // fallback image
          },
        ],
      };
    })
  );

  return {
    ...WORK_LOCATION,
    children: repoFolders.filter(Boolean),
  };
};