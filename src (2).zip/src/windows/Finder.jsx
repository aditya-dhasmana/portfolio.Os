import { WindowControls } from '#components/Index'
import windowWrapper from '#hoc/windowWrapper'
import { Search, ChevronRight, ArrowLeft } from 'lucide-react'
import React from 'react'
import { locations } from '#constants'
import { useLocationStore, useWindowStore } from '#store'
import getFileIcon from "../utils/getFileIcon";
import clsx from 'clsx'
import { useMediaQuery } from 'react-responsive'

const CODE_FILE_TYPES = [
  "js",
  "jsx",
  "ts",
  "tsx",
  "css",
  "html",
  "json",
  "md",
  "txt"
];

const Finder = () => {
  const { openWindow } = useWindowStore();

  const {
    activeLocation,
    setActiveLocation,
    goBackLocation,
    history,
    jumpToLocation,
  } = useLocationStore();

  const isMobile = useMediaQuery({ maxWidth: 640 });

  if (!activeLocation) {
    return <div className="flex items-center justify-center w-full h-full">Loading...</div>;
  }

  // ================= OPEN ITEM =================
  const openItem = (item) => {
    if (!item) return;

    if (item.fileType === "pdf") return openWindow("resume");

    if (item.kind === "folder") return setActiveLocation(item);

    if (item.fileType === "txt" && !item.download_url) return openWindow("txtfile", item);

    if (item.fileType === "img") return openWindow("imgfile", item);

    if (["fig", "url"].includes(item.fileType) && item.href) {
      return window.open(item.href, "_blank");
    }

    if (CODE_FILE_TYPES.includes(item.fileType)) {
      return openWindow("vsCode", { file: item });
    }
  };

  // ================= BREADCRUMB =================
  const buildTrail = (node) => {
  const arr = [];
  let current = node;

  while (current) {
    arr.unshift(current);
    current = current.parent;
  }

  return arr;
};

const breadcrumbTrail = buildTrail(activeLocation);

  const renderBreadcrumbs = () => (
    <div className="flex items-center gap-1 text-xs text-gray-500 px-4 py-2 border-b bg-gray-50 overflow-x-auto whitespace-nowrap">
      {breadcrumbTrail.map((crumb, i) => (
        <React.Fragment key={`${crumb.id}-${i}`}>
          <button
            onClick={() => setActiveLocation(crumb)}
            className="hover:text-black"
          >
            {crumb.name}
          </button>

          {i !== breadcrumbTrail.length - 1 && (
            <ChevronRight className="w-3 h-3" />
          )}
        </React.Fragment>
      ))}
    </div>
  );

  // ================= SIDEBAR =================
  const renderList = (name, items = []) => (
    <div>
      <h3>{name}</h3>
      <ul>
        {items.map((item) => (
          <li
            key={item.id}
            onClick={() => setActiveLocation(item)}
            className={clsx(
              item.id === activeLocation?.id ? 'active' : 'not-active'
            )}
            style={{ cursor: "default" }}
          >
            <img src={item.icon} className='w-4' alt={item.name} />
            <p className="text-sm font-medium truncate">{item.name}</p>
          </li>
        ))}
      </ul>
    </div>
  );

  // ================= MOBILE =================
  if (isMobile) {
    return (
      <div className="fixed inset-0 bg-white flex flex-col">

        <div className="flex items-center justify-between px-4 py-3 border-b bg-white/90">
          <button
            onClick={goBackLocation}
            className="text-black"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>

          <p className="text-sm font-medium">{activeLocation.name}</p>

          <Search className="w-4 h-4 text-black opacity-60" />
        </div>

        {renderBreadcrumbs()}

        <div className="flex-1 overflow-y-auto px-4 py-4">
          <div className="grid grid-cols-3 gap-4">
            {activeLocation?.children?.map((item) => (
              <button
                key={item.id}
                onDoubleClick={() => openItem(item)}
                onClick={() => {}}
                className="flex flex-col items-center"
              >
                <div className="w-14 h-14 flex items-center justify-center">
                  {item.kind === "folder" ? (
                    <img src={item.icon} className="w-10 h-10" />
                  ) : (
                    <div className="text-xl">{getFileIcon(item.name)}</div>
                  )}
                </div>

                <p className="text-[11px] text-center truncate w-full">
                  {item.name}
                </p>
              </button>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // ================= DESKTOP =================
  return (
    <>
      <div id="window-header">
        <WindowControls target='finder' />
        <button onClick={goBackLocation} className="ml-3">
          <ArrowLeft className='icon' />
        </button>
        <Search className='icon' />
      </div>

      {renderBreadcrumbs()}

      <div className="bg-white flex h-full">
        <div className='sidebar'>
          {renderList('Favorites', [
            activeLocation?.type === 'work' ? activeLocation : locations.work,
            locations.about,
            locations.gallery,
            locations.resume
          ])}

          {renderList(
            'Projects',
            activeLocation?.type === 'work' ? activeLocation.children : []
          )}
        </div>

        <div className='content-grid'>
          {activeLocation?.children?.map((item) => (
            <div
              key={item.id}
              className="grid-item"
              onDoubleClick={() => openItem(item)}
              style={{ cursor: "default" }}
            >
              <div className="item-icon-wrapper">
                {item.kind === "folder" ? (
                  <img src={item.icon} className="item-icon-img" />
                ) : (
                  <div className="item-icon-react">
                    {getFileIcon(item.name)}
                  </div>
                )}
              </div>

              <p className="item-name">{item.name}</p>
            </div>
          ))}
        </div>
      </div>
    </>
  );
};

const FinderWindow = windowWrapper(Finder, "finder");
export default FinderWindow;