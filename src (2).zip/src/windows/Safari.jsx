import React from "react";
import { WindowControls } from "#components/Index";
import windowWrapper from "#hoc/windowWrapper";
import {
  ChevronLeft,
  ChevronRight,
  Copy,
  MoveRight,
  PanelLeft,
  Plus,
  Search,
  Share,
  ShieldHalf,
} from "lucide-react";
import { blogPosts } from "#constants";

const Safari = ({ isMobile }) => {
  if (isMobile) {
    return (
      <div className="h-full overflow-y-auto bg-[#f7f7f7] text-black">
        <div className="sticky top-0 bg-white/90 backdrop-blur-xl border-b px-4 py-3 z-10">
          <div className="h-10 rounded-xl bg-black/5 flex items-center px-3 gap-2">
            <Search size={15} />
            <input
              placeholder="Search articles"
              className="bg-transparent outline-none flex-1 text-sm"
            />
          </div>
        </div>

        <div className="p-4 space-y-4">
          <h2 className="text-xl font-semibold">Developer Articles</h2>

          {blogPosts.map(({ id, title, image, date, link }) => (
            <a
              key={id}
              href={link}
              target="_blank"
              rel="noreferrer"
              className="block bg-white rounded-3xl overflow-hidden shadow-sm"
            >
              <img src={image} alt={title} className="w-full h-44 object-cover" />

              <div className="p-4">
                <p className="text-xs text-gray-500 mb-2">{date}</p>
                <h3 className="font-semibold leading-snug">{title}</h3>

                <div className="mt-3 text-sm flex items-center gap-2 opacity-70">
                  Read article <MoveRight size={14} />
                </div>
              </div>
            </a>
          ))}
        </div>
      </div>
    );
  }

  return (
    <>
      <div id="window-header">
        <div className="flex items-center gap-3">
          <WindowControls target="safari" />
          <PanelLeft className="icon" />
          <ChevronLeft className="icon" />
          <ChevronRight className="icon" />
        </div>

        <div className="flex-1 flex justify-center">
          <div className="search">
            <ShieldHalf className="icon" />
            <Search className="icon" />
            <input type="text" placeholder="Search or enter website name" className="flex-1" />
          </div>
        </div>

        <div className="flex items-center gap-5">
          <Share className="icon" />
          <Plus className="icon" />
          <Copy className="icon" />
        </div>
      </div>

      <div className="blog">
        <h2>My Developer Blog</h2>

        <div className="space-y-8">
          {blogPosts.map(({ id, title, image, date, link }) => (
            <div key={id} className="blog-post">
              <div className="col-span-2">
                <img src={image} alt={title} />
              </div>

              <div className="content">
                <p>{date}</p>
                <h3>{title}</h3>
                <a href={link} target="_blank" rel="noopener noreferrer">
                  check out the full post
                  <MoveRight className="icon-hover" />
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
};

export default windowWrapper(Safari, "safari");