import dayjs from "dayjs"
import { navIcons, navLinks } from '#constants'

import React from 'react'
import useWindowStore from "#store/window"
import { OptimizedImage } from "#components/Index"
import { useMediaQuery } from "react-responsive"

const Navbar = () => {
  const { openWindow } = useWindowStore();
  const isMobile = useMediaQuery({ maxWidth: 640 })

  return (
    <nav
        role="banner"
        className={`print:hidden relative z-[50] ${isMobile ? 'bg-transparent backdrop-blur-none p-0' : ''}`}
        >

      {isMobile ? (
        // ✅ MOBILE NAVBAR
        <div className="flex justify-between items-center w-full px-4 py-2 bg-white/20 backdrop-blur-xl border-b border-white/10">
          
          <p className="text-white text-sm font-light drop-shadow-[0_1px_3px_rgba(0,0,0,0.8)]">
            Aditya's portfolio
          </p>

          <button
            onClick={() => openWindow("resume")}
            className="text-white text-sm font-light drop-shadow-[0_1px_3px_rgba(0,0,0,0.8)]"
          >
            Resume
          </button>

        </div>
      ) : (
        // ✅ DESKTOP NAVBAR (UNCHANGED)
        <>
          <div className="flex items-center gap-4">
            <OptimizedImage 
              src="/images/logo.svg" 
              alt="Aditya's Portfolio Logo" 
              className="h-8 w-8 sm:h-10 sm:w-10"
              priority
            />
            <p className='font-bold text-black text-sm sm:text-base lg:text-lg'>
              Aditya's portfolio
            </p>

            <ul className="hidden sm:flex items-center gap-5">
              {navLinks.map(({ id, name , type}) => (
                <li key={id}>
                  <button
                    onClick={() => openWindow(type)}
                    className="text-sm cursor-pointer hover:underline px-2 py-1"
                  >
                    {name}
                  </button>
                </li>
              ))}
            </ul>
          </div>
          
          <div className="flex items-center gap-3">
            <ul className="hidden sm:flex items-center gap-3">
              {navIcons.map(({id,img})=>(
                <li key={id}>
                  <OptimizedImage src={img} className="w-4 h-4" />
                </li>
              ))}
            </ul>

            <time className="text-sm font-medium text-black">
              {dayjs().format("ddd MMM D h:mm A")}
            </time>
          </div>
        </>
      )}
    </nav>
  )
}

export default Navbar