import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowLeft, X } from "lucide-react";
import useWindowStore from "#store/window";

const MobileWindowManager = ({ windowsMap }) => {
  const { windows, closeWindow, minimizeWindow, focusWindow } = useWindowStore();

  const openWindows = Object.entries(windows)
    .filter(([_, win]) => win.isOpen && !win.isMinimized)
    .sort(([_, a], [__, b]) => (b.zIndex || 0) - (a.zIndex || 0));

  if (openWindows.length === 0) return null;

  return (
    <AnimatePresence mode="wait">
      {openWindows.map(([id, win]) => {
        const ScreenComponent = windowsMap[id];
        if (!ScreenComponent) return null;

        return (
          <motion.div
            key={id}
            initial={{ scale: 0.92, opacity: 0, y: 80 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.94, opacity: 0, y: 120 }}
            transition={{ duration: 0.32, ease: "easeOut" }}
            className="fixed inset-0 z-[9999] bg-[#0b0b0b] text-white flex flex-col"
            style={{ zIndex: win.zIndex }}
            onClick={() => focusWindow(id)}
          >
            {/* top native bar */}
            <div className="h-14 px-4 flex items-center justify-between border-b border-white/10 bg-black/70 backdrop-blur-xl">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  minimizeWindow(id);
                }}
                className="flex items-center gap-2 text-sm opacity-90"
              >
                <ArrowLeft size={18} />
                Home
              </button>

              <h2 className="text-sm font-medium capitalize tracking-wide">
                {id.replace(/([A-Z])/g, " $1")}
              </h2>

              <button
                onClick={(e) => {
                  e.stopPropagation();
                  closeWindow(id);
                }}
                className="p-2 rounded-full bg-white/5"
              >
                <X size={16} />
              </button>
            </div>

            <div className="flex-1 overflow-hidden bg-white text-black">
              {React.cloneElement(ScreenComponent, {
                isMobile: true,
                windowId: id,
              })}
            </div>
          </motion.div>
        );
      })}
    </AnimatePresence>
  );
};

export default MobileWindowManager;