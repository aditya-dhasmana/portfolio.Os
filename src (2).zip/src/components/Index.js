import Navbar from "#components/Navbar";
import Welcome from "#components/Welcome";
import Dock from "#components/Dock"
import WindowControls from "./WindowControls";
import MobileDock from "./MobileDock";
import MobileWindowManager from "./MobileWindowManager";
import MobileHomeScreen from "./MobileHomeScreen";
import ErrorBoundary from "./ErrorBoundary";
import LoadingSpinner from "./LoadingSpinner";
import OptimizedImage from "./OptimizedImage";

import Editor from "#components/Editor";
import Explorer from "#components/Explorer";
import Terminal from "#components/Terminal";


import Home from "./Home";


export {Navbar,Welcome,Dock,WindowControls,Home, Terminal , Explorer , Editor , MobileDock, MobileWindowManager, ErrorBoundary, LoadingSpinner, OptimizedImage , MobileHomeScreen};