import React from "react";
import { motion } from "framer-motion";
import { dockApps } from "#constants";
import useWindowStore from "#store/window";
import { OptimizedImage } from "#components/Index";

const MobileHomeScreen = () => {
  const { openWindow } = useWindowStore();

  return (
    <div className="mobile-home-screen">

      {/* Wallpaper overlay */}
      <div className="mobile-wallpaper-glow" />

      {/* Clock */}
      <div className="mobile-clock-block">
        <h1>{new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</h1>
        <p>{new Date().toLocaleDateString([], { weekday: "long", month: "long", day: "numeric" })}</p>
      </div>

      {/* Mini Widget */}
      <div className="mobile-widget-card">
        <p>Aditya Portfolio OS</p>
        <span>Interactive Developer Experience</span>
      </div>

      {/* Apps Grid */}
      <div className="mobile-app-grid">
        {dockApps.map((app, index) => (
          <motion.button
            key={app.id}
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
            whileTap={{ scale: 0.88 }}
            className="mobile-app-icon"
            onClick={() => openWindow(app.id)}
          >
            <OptimizedImage
              src={`/images/${app.icon}`}
              alt={app.name}
              className="w-14 h-14 object-contain"
            />
            <span>{app.name}</span>
          </motion.button>
        ))}
      </div>
    </div>
  );
};

export default MobileHomeScreen;