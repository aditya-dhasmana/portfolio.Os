import { dockApps } from "#constants/index";
import useWindowStore from "#store/window";
import { OptimizedImage } from "#components/Index";
import { motion } from "framer-motion";

const MobileDock = () => {
  const { openWindow, windows, restoreWindow } = useWindowStore();

  const mobileApps = dockApps;

  const handleOpen = (id) => {
    const win = windows[id];

    if (win?.isMinimized) return restoreWindow(id);
    openWindow(id);
  };

  return (
    <div className="md:hidden fixed bottom-5 left-1/2 -translate-x-1/2 z-[10000]">
      <div className="px-4 py-3 rounded-[28px] bg-white/10 backdrop-blur-2xl border border-white/10 shadow-2xl">
        <div className="flex items-center gap-4">
          {mobileApps.map(({ id, name, icon }) => (
            <motion.button
              whileTap={{ scale: 0.82 }}
              key={id}
              onClick={() => handleOpen(id)}
              className="relative flex flex-col items-center"
            >
              <div className="w-14 h-14 rounded-2xl bg-white/5 flex items-center justify-center shadow-lg">
                <OptimizedImage
                  src={`/images/${icon}`}
                  alt={name}
                  className="w-10 h-10 object-contain"
                />
              </div>

              {windows[id]?.isOpen && (
                <span className="absolute -bottom-1 w-1.5 h-1.5 rounded-full bg-white" />
              )}
            </motion.button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default MobileDock;