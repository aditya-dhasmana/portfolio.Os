// src/mobile/MobileApp.jsx

import React from "react";
import Home from "./pages/Home/MobileHome";

const MobileApp = () => {
  return <Home />;
};

export default MobileApp;