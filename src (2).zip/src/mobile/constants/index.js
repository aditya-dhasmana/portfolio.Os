// src/mobile/constants/index.js

/*
|--------------------------------------------------------------------------
| iOS STATUS BAR
|--------------------------------------------------------------------------
*/

export const STATUS_BAR = {
  carrier: "Portfolio",
  showWifi: true,
  showSignal: true,
  battery: 100,
};

/*
|--------------------------------------------------------------------------
| HOME SCREEN
|--------------------------------------------------------------------------
*/

export const HOME_SCREEN = {
  wallpaper: "/images/wallpaper.jpg", // same wallpaper as desktop
  showClock: true,
  showDate: true,
};


export const navIcons = [
  {
    id: 1,
    img: "/icons/wifi.svg",
  },
  {
    id: 2,
    img: "/icons/search.svg",
  },
  {
    id: 3,
    img: "/icons/user.svg",
  },
  {
    id: 4,
    img: "/icons/mode.svg",
  },
];
/*
|--------------------------------------------------------------------------
| MOBILE APPS
|--------------------------------------------------------------------------
| id          -> unique identifier
| name        -> label shown under icon
| icon        -> image filename from /public/icons/apps/
| type        -> window/app type to open
| canOpen     -> whether app is interactive
| dock        -> show in bottom dock
|--------------------------------------------------------------------------
*/

export const MOBILE_APPS = [
  // Home screen apps
  {
    id: "about",
    name: "About",
    icon: "about.png",
    type: "about",
    canOpen: true,
    dock: false,
  },
  {
    id: "finder",
    name: "Projects",
    icon: "finder.png",
    type: "finder",
    canOpen: true,
    dock: false,
  },
  {
    id: "terminal",
    name: "Skills",
    icon: "terminal.png",
    type: "terminal",
    canOpen: true,
    dock: false,
  },
  {
    id: "safari",
    name: "Articles",
    icon: "safari.png",
    type: "safari",
    canOpen: true,
    dock: false,
  },
  {
    id: "github",
    name: "GitHub",
    icon: "github.png",
    type: "github",
    canOpen: true,
    dock: false,
  },
  {
    id: "vscode",
    name: "VS Code",
    icon: "vscode.png",
    type: "vsCode",
    canOpen: true,
    dock: false,
  },
  {
    id: "notes",
    name: "Notes",
    icon: "notes.png",
    type: "notes",
    canOpen: true,
    dock: false,
  },
  {
    id: "settings",
    name: "Settings",
    icon: "settings.png",
    type: "settings",
    canOpen: true,
    dock: false,
  },

  // Dock apps
  {
    id: "resume",
    name: "Resume",
    icon: "resume.png",
    type: "resume",
    canOpen: true,
    dock: true,
  },
  {
    id: "gallery",
    name: "Gallery",
    icon: "photos.png",
    type: "gallery",
    canOpen: true,
    dock: true,
  },
  {
    id: "contact",
    name: "Contact",
    icon: "contact.png",
    type: "contact",
    canOpen: true,
    dock: true,
  },
  {
    id: "phone",
    name: "Phone",
    icon: "phone.png",
    type: "contact",
    canOpen: true,
    dock: true,
  },
];

/*
|--------------------------------------------------------------------------
| DERIVED DATA
|--------------------------------------------------------------------------
*/

export const DOCK_APPS = MOBILE_APPS.filter((app) => app.dock);
export const HOME_APPS = MOBILE_APPS.filter((app) => !app.dock);

/*
|--------------------------------------------------------------------------
| APP GRID SETTINGS
|--------------------------------------------------------------------------
*/

export const APP_GRID = {
  columns: 4,
  gap: 20,
};

/*
|--------------------------------------------------------------------------
| DOCK SETTINGS
|--------------------------------------------------------------------------
*/

export const DOCK = {
  maxApps: 4,
};

/*
|--------------------------------------------------------------------------
| CLOCK FORMAT
|--------------------------------------------------------------------------
*/

export const CLOCK_OPTIONS = {
  time: {
    hour: "numeric",
    minute: "2-digit",
  },
  date: {
    weekday: "long",
    month: "long",
    day: "numeric",
  },
};