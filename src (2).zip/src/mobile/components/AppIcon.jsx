// src/mobile/components/AppIcon.jsx

import React from "react";

const AppIcon = ({ app, onClick }) => {
  return (
    <button
      onClick={() => onClick?.(app)}
      className="flex flex-col items-center gap-1 active:scale-95 transition-transform"
    >
      <img
        src={app.icon}
        alt={app.name}
        className="w-14 h-14 rounded-2xl object-contain"
      />

      <span className="text-[11px] font-medium text-white drop-shadow-md">
        {app.name}
      </span>
    </button>
  );
};

export default AppIcon;