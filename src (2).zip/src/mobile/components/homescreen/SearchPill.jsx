// src/mobile/components/SearchPill.jsx

import React from "react";
import { Search } from "lucide-react";

const SearchPill = () => {
  return (
    <div className="my-4 flex justify-center">
      <div className="flex h-9 w-44 items-center justify-center gap-2 rounded-full bg-white/20 backdrop-blur-xl">
        <Search size={16} />
        <span className="text-sm">Search</span>
      </div>
    </div>
  );
};

export default SearchPill;