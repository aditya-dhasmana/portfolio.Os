// src/mobile/components/StatusBar.jsx

import React, { useEffect, useState } from "react";

const StatusBar = () => {
  const [time, setTime] = useState("");

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTime(
        now.toLocaleTimeString([], {
          hour: "2-digit",
          minute: "2-digit",
          hour12: false,
        })
      );
    };

    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex items-center justify-between px-2 text-sm font-semibold">
      <span>{time}</span>

      <div className="flex items-center gap-1">
        <i className="fas fa-signal" />
        <i className="fas fa-wifi" />
        <span className="text-xs">100%</span>
      </div>
    </div>
  );
};

export default StatusBar;