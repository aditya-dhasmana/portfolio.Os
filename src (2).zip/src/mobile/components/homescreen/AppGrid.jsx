// src/mobile/components/AppGrid.jsx

import React from "react";
import { HOME_APPS } from "../../constants";
import AppIcon from "./AppIcon";

const AppGrid = ({ onOpenApp }) => {
  return (
    <div className="grid grid-cols-4 gap-x-4 gap-y-6">
      {HOME_APPS.map((app) => (
        <AppIcon key={app.id} app={app} onClick={onOpenApp} />
      ))}
    </div>
  );
};

export default AppGrid;