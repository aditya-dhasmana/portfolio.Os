// src/mobile/components/DynamicIsland.jsx

import React from "react";

const DynamicIsland = () => {
  return (
    <div className="mt-2 flex justify-center">
      <div className="h-8 w-32 rounded-full bg-black" />
    </div>
  );
};

export default DynamicIsland;