// src/mobile/components/AppIcon.jsx

import React from "react";

const AppIcon = ({ app, onClick }) => {
  return (
    <button
      onClick={() => onClick?.(app)}
      className="flex flex-col items-center gap-1"
    >
      <img
        src={`/icons/apps/${app.icon}`}
        alt={app.name}
        className="h-14 w-14 rounded-2xl object-cover"
      />
      <span className="text-[11px] font-medium">{app.name}</span>
    </button>
  );
};

export default AppIcon;