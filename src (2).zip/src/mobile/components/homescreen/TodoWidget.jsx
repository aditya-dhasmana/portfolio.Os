// src/mobile/components/TodoWidget.jsx

import React from "react";

const tasks = [
  "Build cool apps",
  "Ship portfolio",
  "Get hired",
];

const TodoWidget = () => {
  return (
    <div className="rounded-3xl bg-black/25 backdrop-blur-xl p-4">
      <p className="text-xs uppercase text-white/70">Todo</p>
      <ul className="mt-2 space-y-1 text-sm font-medium">
        {tasks.map((task) => (
          <li key={task}>• {task}</li>
        ))}
      </ul>
    </div>
  );
};

export default TodoWidget;