// src/mobile/components/WeatherWidget.jsx

import React from "react";

const WeatherWidget = () => {
  return (
    <div className="rounded-3xl bg-blue-500/40 backdrop-blur-xl p-4">
      <p className="text-xs uppercase text-white/80">Delhi</p>
      <div className="mt-2 flex items-end justify-between">
        <span className="text-4xl font-light">32°</span>
        <span className="text-sm">Sunny</span>
      </div>
    </div>
  );
};

export default WeatherWidget;