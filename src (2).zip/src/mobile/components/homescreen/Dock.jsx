// src/mobile/components/Dock.jsx

import React from "react";
import { DOCK_APPS } from "../../constants/index";
import AppIcon from "./AppIcon";

const Dock = ({ onOpenApp }) => {
  return (
    <div className="mb-2 rounded-[2rem] bg-white/20 backdrop-blur-2xl px-4 py-3">
      <div className="grid grid-cols-4 gap-4">
        {DOCK_APPS.map((app) => (
          <AppIcon key={app.id} app={app} onClick={onOpenApp} />
        ))}
      </div>
    </div>
  );
};

export default Dock;