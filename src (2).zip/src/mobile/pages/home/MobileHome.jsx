// src/mobile/pages/Home.jsx

import React from "react";
import {
  StatusBar,
  DynamicIsland,
  TodoWidget,
  WeatherWidget,
  AppGrid,
  SearchPill,
  Dock,
} from "../../components";
import { HOME_SCREEN } from "../../constants";

const Home = () => {
  return (
    <div
      className="relative w-full h-full bg-cover bg-center bg-no-repeat overflow-hidden text-white"
      style={{
        backgroundImage: `url(${HOME_SCREEN.wallpaper})`,
      }}
    >
      {/* Dark overlay for readability */}
      <div className="absolute inset-0 bg-black/10" />

      {/* Content */}
      <div className="relative z-10 flex h-full flex-col px-4 pt-3 pb-2">
        {/* Top Section */}
        <StatusBar />
        <DynamicIsland />

        {/* Widgets */}
        <div className="mt-6 grid grid-cols-2 gap-3">
          <TodoWidget />
          <WeatherWidget />
        </div>

        {/* App Icons */}
        <div className="mt-6 flex-1">
          <AppGrid />
        </div>

        {/* Search */}
        <SearchPill />

        {/* Dock */}
        <Dock />
      </div>
    </div>
  );
};

export default Home;