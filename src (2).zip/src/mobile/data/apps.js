import AboutPage from '../pages/AboutPage';
import ProjectsPage from '../pages/ProjectsPage';
import ContactPage from '../pages/ContactPage';

export const apps = [
  {
    id: 'about',
    name: 'About',
    icon: '👤',
    component: AboutPage,
  },
  {
    id: 'projects',
    name: 'Projects',
    icon: '💼',
    component: ProjectsPage,
  },
  {
    id: 'contact',
    name: 'Contact',
    icon: '✉️',
    component: ContactPage,
  },
];